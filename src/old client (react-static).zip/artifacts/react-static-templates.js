

  
// Template Map
export default {
  '../src/pages/404.jsx': require('../src/pages/404.jsx').default,
'../src/pages/about.jsx': require('../src/pages/about.jsx').default,
'../src/pages/artist.jsx': require('../src/pages/artist.jsx').default,
'../src/pages/artists.jsx': require('../src/pages/artists.jsx').default,
'../src/pages/index.jsx': require('../src/pages/index.jsx').default,
'../src/pages/producer-tool.jsx': require('../src/pages/producer-tool.jsx').default,
'../src/pages/producer-tools.jsx': require('../src/pages/producer-tools.jsx').default,
'../src/containers/Admin': require('../src/containers/Admin').default,
'../src/containers/Artist': require('../src/containers/Artist').default,
'../src/pages/producer-tool': require('../src/pages/producer-tool').default
}

export const notFoundTemplate = '../src/pages/404.jsx'

